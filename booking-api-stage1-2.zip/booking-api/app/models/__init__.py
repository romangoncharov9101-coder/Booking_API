# This file ensures all models are imported and registered with SQLAlchemy's
# metadata before Alembic generates migrations or the app creates tables.

from app.models.audit_log import AuditLog  # noqa: F401
from app.models.booking import Booking  # noqa: F401
from app.models.notification import NotificationEvent  # noqa: F401
from app.models.review import Review  # noqa: F401
from app.models.user import RefreshToken, User  # noqa: F401
from app.models.venue import (  # noqa: F401
    Resource,
    ResourceWorkingHours,
    ScheduleException,
    Service,
    ServiceResource,
    Venue,
    VenueWorkingHours,
)
from app.models.waitlist import WaitlistEntry  # noqa: F401

__all__ = [
    "User",
    "RefreshToken",
    "Venue",
    "Service",
    "Resource",
    "ServiceResource",
    "VenueWorkingHours",
    "ResourceWorkingHours",
    "ScheduleException",
    "Booking",
    "WaitlistEntry",
    "NotificationEvent",
    "AuditLog",
    "Review",
]
