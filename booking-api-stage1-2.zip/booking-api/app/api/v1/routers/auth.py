from typing import Annotated

from fastapi import APIRouter, Depends, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import CurrentUser, get_db
from app.schemas.auth import (
    LoginRequest,
    LogoutRequest,
    RefreshRequest,
    RegisterRequest,
    TokenResponse,
    UserResponse,
)
from app.services.auth_service import AuthService

router = APIRouter(prefix="/auth", tags=["auth"])

DB = Annotated[AsyncSession, Depends(get_db)]


def _user_agent(request: Request) -> str | None:
    return request.headers.get("User-Agent")


def _ip_address(request: Request) -> str | None:
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else None


@router.post(
    "/register",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Register a new user account",
)
async def register(payload: RegisterRequest, db: DB) -> UserResponse:
    svc = AuthService(db)
    user = await svc.register(payload)
    await db.commit()
    return UserResponse.model_validate(user)


@router.post(
    "/login",
    response_model=TokenResponse,
    summary="Login with email or username",
)
async def login(payload: LoginRequest, request: Request, db: DB) -> TokenResponse:
    svc = AuthService(db)
    tokens = await svc.login(
        payload,
        user_agent=_user_agent(request),
        ip_address=_ip_address(request),
    )
    await db.commit()
    return tokens


@router.post(
    "/refresh",
    response_model=TokenResponse,
    summary="Exchange a refresh token for a new token pair (rotation)",
)
async def refresh(payload: RefreshRequest, request: Request, db: DB) -> TokenResponse:
    svc = AuthService(db)
    tokens = await svc.refresh(
        payload.refresh_token,
        user_agent=_user_agent(request),
        ip_address=_ip_address(request),
    )
    await db.commit()
    return tokens


@router.post(
    "/logout",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Revoke current refresh token",
)
async def logout(payload: LogoutRequest, db: DB) -> None:
    svc = AuthService(db)
    await svc.logout(payload.refresh_token)
    await db.commit()


@router.post(
    "/logout-all",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Revoke all refresh tokens for the current user (all devices)",
)
async def logout_all(current_user: CurrentUser, db: DB) -> None:
    svc = AuthService(db)
    await svc.logout_all(current_user.id)
    await db.commit()


@router.get(
    "/me",
    response_model=UserResponse,
    summary="Get current authenticated user",
)
async def me(current_user: CurrentUser) -> UserResponse:
    return UserResponse.model_validate(current_user)
