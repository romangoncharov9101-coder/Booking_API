"""Unit tests for core/security.py"""
import uuid

import pytest

from app.core.exceptions import TokenExpiredError, TokenInvalidError
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_access_token,
    decode_refresh_token,
    generate_jti,
    hash_password,
    hash_token,
    verify_password,
)


class TestPasswordHashing:
    def test_hash_is_not_plain(self):
        h = hash_password("MySecret1")
        assert h != "MySecret1"

    def test_verify_correct(self):
        h = hash_password("MySecret1")
        assert verify_password("MySecret1", h) is True

    def test_verify_wrong(self):
        h = hash_password("MySecret1")
        assert verify_password("WrongPass", h) is False

    def test_two_hashes_differ(self):
        """Hashes must be salted — same input produces different outputs."""
        h1 = hash_password("MySecret1")
        h2 = hash_password("MySecret1")
        assert h1 != h2


class TestJWT:
    def _user_id(self):
        return uuid.uuid4()

    def test_access_token_round_trip(self):
        uid = self._user_id()
        token = create_access_token(uid, "u@test.com", "testuser", "user")
        payload = decode_access_token(token)
        assert payload["sub"] == str(uid)
        assert payload["email"] == "u@test.com"
        assert payload["role"] == "user"
        assert payload["type"] == "access"

    def test_refresh_token_round_trip(self):
        uid = self._user_id()
        jti = generate_jti()
        token = create_refresh_token(uid, jti)
        payload = decode_refresh_token(token)
        assert payload["sub"] == str(uid)
        assert payload["jti"] == jti
        assert payload["type"] == "refresh"

    def test_access_token_rejected_as_refresh(self):
        uid = self._user_id()
        token = create_access_token(uid, "u@test.com", "testuser", "user")
        with pytest.raises(TokenInvalidError):
            decode_refresh_token(token)

    def test_refresh_token_rejected_as_access(self):
        uid = self._user_id()
        token = create_refresh_token(uid, generate_jti())
        with pytest.raises(TokenInvalidError):
            decode_access_token(token)

    def test_invalid_token_raises(self):
        with pytest.raises(TokenInvalidError):
            decode_access_token("not.a.token")

    def test_hash_token_deterministic(self):
        raw = "some-refresh-token"
        assert hash_token(raw) == hash_token(raw)

    def test_hash_token_differs_for_different_inputs(self):
        assert hash_token("token-a") != hash_token("token-b")
