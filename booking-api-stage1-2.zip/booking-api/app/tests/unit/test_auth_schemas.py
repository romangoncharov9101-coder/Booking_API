"""Unit tests for auth schema validation rules."""
import pytest
from pydantic import ValidationError

from app.schemas.auth import (
    LoginRequest,
    PasswordChangeRequest,
    RegisterRequest,
)


class TestRegisterRequest:
    def test_valid(self):
        r = RegisterRequest(email="User@Example.COM", username="john_doe", password="Password1")
        assert r.email == "user@example.com"  # lowercased
        assert r.username == "john_doe"

    def test_password_too_short(self):
        with pytest.raises(ValidationError, match="at least 8"):
            RegisterRequest(email="a@b.com", username="user", password="Ab1")

    def test_password_no_digit(self):
        with pytest.raises(ValidationError, match="letter and one digit"):
            RegisterRequest(email="a@b.com", username="user", password="OnlyLetters")

    def test_password_no_letter(self):
        with pytest.raises(ValidationError, match="letter and one digit"):
            RegisterRequest(email="a@b.com", username="user", password="12345678")

    def test_invalid_email(self):
        with pytest.raises(ValidationError):
            RegisterRequest(email="not-an-email", username="user", password="Password1")

    def test_username_too_short(self):
        with pytest.raises(ValidationError):
            RegisterRequest(email="a@b.com", username="ab", password="Password1")

    def test_username_invalid_chars(self):
        with pytest.raises(ValidationError, match="Username may only"):
            RegisterRequest(email="a@b.com", username="user name!", password="Password1")

    def test_username_valid_chars(self):
        r = RegisterRequest(email="a@b.com", username="user.name-123_ok", password="Password1")
        assert r.username == "user.name-123_ok"


class TestPasswordChangeRequest:
    def test_same_password_rejected(self):
        with pytest.raises(ValidationError, match="must differ"):
            PasswordChangeRequest(current_password="Password1", new_password="Password1")

    def test_valid(self):
        p = PasswordChangeRequest(current_password="OldPass1", new_password="NewPass2")
        assert p.new_password == "NewPass2"
