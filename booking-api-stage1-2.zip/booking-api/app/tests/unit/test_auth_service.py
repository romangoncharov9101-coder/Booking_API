"""
Unit tests for AuthService.

We mock the repositories so these tests run instantly without a DB.
"""
import uuid
from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.core.exceptions import (
    InvalidCredentialsError,
    TokenRevokedError,
    UserEmailAlreadyExistsError,
    UserInactiveError,
    UsernameAlreadyExistsError,
)
from app.core.security import hash_password, hash_token, create_refresh_token, generate_jti
from app.models.user import User, UserRole
from app.models.user import RefreshToken
from app.schemas.auth import LoginRequest, RegisterRequest
from app.services.auth_service import AuthService


def _make_user(**kwargs) -> User:
    defaults = dict(
        id=uuid.uuid4(),
        email="test@example.com",
        username="testuser",
        password_hash=hash_password("Password1"),
        role=UserRole.USER,
        is_active=True,
        is_verified=False,
        first_name=None,
        last_name=None,
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )
    defaults.update(kwargs)
    user = MagicMock(spec=User)
    for k, v in defaults.items():
        setattr(user, k, v)
    return user


def _make_refresh_token(user_id: uuid.UUID, *, revoked: bool = False) -> RefreshToken:
    jti = generate_jti()
    raw = create_refresh_token(user_id, jti)
    token = MagicMock(spec=RefreshToken)
    token.user_id = user_id
    token.token_hash = hash_token(raw)
    token.expires_at = datetime.now(UTC) + timedelta(days=14)
    token.revoked_at = datetime.now(UTC) if revoked else None
    token.is_valid = not revoked
    return token, raw


@pytest.fixture
def mock_db():
    return AsyncMock()


@pytest.fixture
def svc(mock_db):
    service = AuthService(mock_db)
    service._users = AsyncMock()
    service._tokens = AsyncMock()
    return service


# ─── register ─────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_register_success(svc):
    svc._users.email_exists.return_value = False
    svc._users.username_exists.return_value = False
    expected_user = _make_user()
    svc._users.create.return_value = expected_user

    payload = RegisterRequest(
        email="new@example.com",
        username="newuser",
        password="Password1",
    )
    user = await svc.register(payload)

    assert user is expected_user
    svc._users.create.assert_called_once()
    call_kwargs = svc._users.create.call_args.kwargs
    assert call_kwargs["email"] == "new@example.com"
    # Password must be stored as a hash, never plain text
    assert call_kwargs["password_hash"] != "Password1"


@pytest.mark.asyncio
async def test_register_duplicate_email(svc):
    svc._users.email_exists.return_value = True

    with pytest.raises(UserEmailAlreadyExistsError):
        await svc.register(
            RegisterRequest(email="dup@example.com", username="user2", password="Password1")
        )


@pytest.mark.asyncio
async def test_register_duplicate_username(svc):
    svc._users.email_exists.return_value = False
    svc._users.username_exists.return_value = True

    with pytest.raises(UsernameAlreadyExistsError):
        await svc.register(
            RegisterRequest(email="new@example.com", username="taken", password="Password1")
        )


# ─── login ────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_login_success_by_email(svc):
    user = _make_user(password_hash=hash_password("Password1"))
    svc._users.get_by_login.return_value = user
    svc._tokens.create.return_value = AsyncMock()

    tokens = await svc.login(
        LoginRequest(login="test@example.com", password="Password1")
    )

    assert tokens.access_token
    assert tokens.refresh_token
    assert tokens.token_type == "bearer"


@pytest.mark.asyncio
async def test_login_wrong_password(svc):
    user = _make_user(password_hash=hash_password("Password1"))
    svc._users.get_by_login.return_value = user

    with pytest.raises(InvalidCredentialsError):
        await svc.login(LoginRequest(login="test@example.com", password="WrongPass1"))


@pytest.mark.asyncio
async def test_login_user_not_found_no_info_leak(svc):
    """Must raise InvalidCredentialsError, NOT UserNotFoundError — prevents user enumeration."""
    svc._users.get_by_login.return_value = None

    with pytest.raises(InvalidCredentialsError):
        await svc.login(LoginRequest(login="ghost@example.com", password="Password1"))


@pytest.mark.asyncio
async def test_login_inactive_user(svc):
    user = _make_user(password_hash=hash_password("Password1"), is_active=False)
    svc._users.get_by_login.return_value = user

    with pytest.raises(UserInactiveError):
        await svc.login(LoginRequest(login="test@example.com", password="Password1"))


# ─── refresh ──────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_refresh_success(svc):
    user = _make_user()
    stored_token, raw = _make_refresh_token(user.id)

    svc._tokens.get_by_hash.return_value = stored_token
    svc._users.get_by_id.return_value = user
    svc._tokens.create.return_value = AsyncMock()

    tokens = await svc.refresh(raw)

    assert tokens.access_token
    assert tokens.refresh_token
    # Old token must be revoked
    svc._tokens.revoke.assert_called_once_with(stored_token)


@pytest.mark.asyncio
async def test_refresh_revoked_token_triggers_revoke_all(svc):
    """Token reuse attack: revoked token used → revoke ALL tokens for the user."""
    user_id = uuid.uuid4()
    stored_token, raw = _make_refresh_token(user_id, revoked=True)
    stored_token.revoked_at = datetime.now(UTC)

    svc._tokens.get_by_hash.return_value = stored_token

    with pytest.raises(TokenRevokedError):
        await svc.refresh(raw)

    svc._tokens.revoke_all_for_user.assert_called_once_with(user_id)


# ─── logout ───────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_logout_revokes_token(svc):
    user_id = uuid.uuid4()
    stored_token, raw = _make_refresh_token(user_id)
    svc._tokens.get_by_hash.return_value = stored_token

    await svc.logout(raw)

    svc._tokens.revoke.assert_called_once_with(stored_token)


@pytest.mark.asyncio
async def test_logout_unknown_token_is_no_op(svc):
    """Logging out with an unknown token should not raise."""
    svc._tokens.get_by_hash.return_value = None

    await svc.logout("unknown-token")  # must not raise
