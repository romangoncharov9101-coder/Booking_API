"""Integration tests for /api/v1/users/* endpoints."""
import pytest
from httpx import AsyncClient

REGISTER_URL = "/api/v1/auth/register"
LOGIN_URL = "/api/v1/auth/login"
USERS_ME_URL = "/api/v1/users/me"
CHANGE_PW_URL = "/api/v1/users/me/change-password"


async def _register_and_login(client: AsyncClient, email: str, username: str) -> dict:
    await client.post(REGISTER_URL, json={
        "email": email, "username": username, "password": "Password1"
    })
    r = await client.post(LOGIN_URL, json={"login": username, "password": "Password1"})
    return r.json()


@pytest.mark.asyncio
async def test_get_me(client: AsyncClient):
    tokens = await _register_and_login(client, "bob@test.com", "bobuser")
    r = await client.get(USERS_ME_URL, headers={"Authorization": f"Bearer {tokens['access_token']}"})
    assert r.status_code == 200
    assert r.json()["username"] == "bobuser"


@pytest.mark.asyncio
async def test_update_me(client: AsyncClient):
    tokens = await _register_and_login(client, "carol@test.com", "caroluser")
    r = await client.patch(
        USERS_ME_URL,
        json={"first_name": "Carol", "last_name": "Smith"},
        headers={"Authorization": f"Bearer {tokens['access_token']}"},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["first_name"] == "Carol"
    assert body["last_name"] == "Smith"


@pytest.mark.asyncio
async def test_change_password_success(client: AsyncClient):
    tokens = await _register_and_login(client, "dave@test.com", "daveuser")
    r = await client.post(
        CHANGE_PW_URL,
        json={"current_password": "Password1", "new_password": "NewPassword2"},
        headers={"Authorization": f"Bearer {tokens['access_token']}"},
    )
    assert r.status_code == 204

    # Old refresh token should be revoked after password change
    r2 = await client.post("/api/v1/auth/refresh", json={"refresh_token": tokens["refresh_token"]})
    assert r2.status_code in (401, 403)

    # Can log in with new password
    r3 = await client.post(LOGIN_URL, json={"login": "daveuser", "password": "NewPassword2"})
    assert r3.status_code == 200


@pytest.mark.asyncio
async def test_change_password_wrong_current(client: AsyncClient):
    tokens = await _register_and_login(client, "eve@test.com", "eveuser")
    r = await client.post(
        CHANGE_PW_URL,
        json={"current_password": "WrongPass1", "new_password": "NewPassword2"},
        headers={"Authorization": f"Bearer {tokens['access_token']}"},
    )
    assert r.status_code == 401


@pytest.mark.asyncio
async def test_get_user_by_id_requires_admin(client: AsyncClient):
    import uuid
    tokens = await _register_and_login(client, "frank@test.com", "frankuser")
    r = await client.get(
        f"/api/v1/users/{uuid.uuid4()}",
        headers={"Authorization": f"Bearer {tokens['access_token']}"},
    )
    assert r.status_code == 403
