"""
Integration tests for /api/v1/auth/* endpoints.

These tests hit the real FastAPI app with a real (test) DB transaction
that is rolled back after each test — isolation guaranteed.
"""
import pytest
from httpx import AsyncClient


REGISTER_URL = "/api/v1/auth/register"
LOGIN_URL = "/api/v1/auth/login"
REFRESH_URL = "/api/v1/auth/refresh"
LOGOUT_URL = "/api/v1/auth/logout"
LOGOUT_ALL_URL = "/api/v1/auth/logout-all"
ME_URL = "/api/v1/auth/me"

VALID_USER = {
    "email": "alice@example.com",
    "username": "alice",
    "password": "AlicePass1",
    "first_name": "Alice",
}


# ─── Register ─────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_register_201(client: AsyncClient):
    r = await client.post(REGISTER_URL, json=VALID_USER)
    assert r.status_code == 201
    body = r.json()
    assert body["email"] == "alice@example.com"
    assert body["username"] == "alice"
    assert body["role"] == "user"
    assert body["is_active"] is True
    assert "password_hash" not in body  # never leak hash


@pytest.mark.asyncio
async def test_register_duplicate_email(client: AsyncClient):
    await client.post(REGISTER_URL, json=VALID_USER)
    r = await client.post(REGISTER_URL, json={**VALID_USER, "username": "alice2"})
    assert r.status_code == 409
    assert r.json()["error"]["code"] == "USER_EMAIL_ALREADY_EXISTS"


@pytest.mark.asyncio
async def test_register_duplicate_username(client: AsyncClient):
    await client.post(REGISTER_URL, json=VALID_USER)
    r = await client.post(REGISTER_URL, json={**VALID_USER, "email": "other@example.com"})
    assert r.status_code == 409
    assert r.json()["error"]["code"] == "USER_USERNAME_ALREADY_EXISTS"


@pytest.mark.asyncio
async def test_register_weak_password(client: AsyncClient):
    r = await client.post(REGISTER_URL, json={**VALID_USER, "password": "weak"})
    assert r.status_code == 422


@pytest.mark.asyncio
async def test_register_invalid_email(client: AsyncClient):
    r = await client.post(REGISTER_URL, json={**VALID_USER, "email": "not-an-email"})
    assert r.status_code == 422


# ─── Login ────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_login_by_email(client: AsyncClient):
    await client.post(REGISTER_URL, json=VALID_USER)
    r = await client.post(LOGIN_URL, json={"login": "alice@example.com", "password": "AlicePass1"})
    assert r.status_code == 200
    body = r.json()
    assert "access_token" in body
    assert "refresh_token" in body
    assert body["token_type"] == "bearer"


@pytest.mark.asyncio
async def test_login_by_username(client: AsyncClient):
    await client.post(REGISTER_URL, json=VALID_USER)
    r = await client.post(LOGIN_URL, json={"login": "alice", "password": "AlicePass1"})
    assert r.status_code == 200


@pytest.mark.asyncio
async def test_login_wrong_password(client: AsyncClient):
    await client.post(REGISTER_URL, json=VALID_USER)
    r = await client.post(LOGIN_URL, json={"login": "alice", "password": "WrongPass1"})
    assert r.status_code == 401
    assert r.json()["error"]["code"] == "AUTH_INVALID_CREDENTIALS"


@pytest.mark.asyncio
async def test_login_nonexistent_user(client: AsyncClient):
    r = await client.post(LOGIN_URL, json={"login": "ghost@example.com", "password": "Pass1234"})
    # Must return the same 401 as wrong password — no user enumeration
    assert r.status_code == 401
    assert r.json()["error"]["code"] == "AUTH_INVALID_CREDENTIALS"


# ─── Me ───────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_me_authenticated(client: AsyncClient):
    await client.post(REGISTER_URL, json=VALID_USER)
    login_r = await client.post(LOGIN_URL, json={"login": "alice", "password": "AlicePass1"})
    token = login_r.json()["access_token"]

    r = await client.get(ME_URL, headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200
    assert r.json()["username"] == "alice"


@pytest.mark.asyncio
async def test_me_unauthenticated(client: AsyncClient):
    r = await client.get(ME_URL)
    assert r.status_code == 401


@pytest.mark.asyncio
async def test_me_invalid_token(client: AsyncClient):
    r = await client.get(ME_URL, headers={"Authorization": "Bearer not.a.real.token"})
    assert r.status_code == 401


# ─── Refresh ──────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_refresh_returns_new_pair(client: AsyncClient):
    await client.post(REGISTER_URL, json=VALID_USER)
    login_r = await client.post(LOGIN_URL, json={"login": "alice", "password": "AlicePass1"})
    old_refresh = login_r.json()["refresh_token"]

    r = await client.post(REFRESH_URL, json={"refresh_token": old_refresh})
    assert r.status_code == 200
    new_tokens = r.json()
    assert new_tokens["access_token"]
    assert new_tokens["refresh_token"]
    # New tokens must differ from old ones
    assert new_tokens["refresh_token"] != old_refresh


@pytest.mark.asyncio
async def test_refresh_old_token_revoked_after_rotation(client: AsyncClient):
    """After rotation the old refresh token must no longer work."""
    await client.post(REGISTER_URL, json=VALID_USER)
    login_r = await client.post(LOGIN_URL, json={"login": "alice", "password": "AlicePass1"})
    old_refresh = login_r.json()["refresh_token"]

    # First refresh — succeeds, rotates the token
    await client.post(REFRESH_URL, json={"refresh_token": old_refresh})

    # Second refresh with the same (now revoked) token — must fail
    r = await client.post(REFRESH_URL, json={"refresh_token": old_refresh})
    assert r.status_code in (401, 403)


@pytest.mark.asyncio
async def test_refresh_invalid_token(client: AsyncClient):
    r = await client.post(REFRESH_URL, json={"refresh_token": "garbage"})
    assert r.status_code == 401


# ─── Logout ───────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_logout_invalidates_refresh_token(client: AsyncClient):
    await client.post(REGISTER_URL, json=VALID_USER)
    login_r = await client.post(LOGIN_URL, json={"login": "alice", "password": "AlicePass1"})
    tokens = login_r.json()

    r = await client.post(LOGOUT_URL, json={"refresh_token": tokens["refresh_token"]})
    assert r.status_code == 204

    # Refresh must now fail
    r2 = await client.post(REFRESH_URL, json={"refresh_token": tokens["refresh_token"]})
    assert r2.status_code in (401, 403)


@pytest.mark.asyncio
async def test_logout_all(client: AsyncClient):
    await client.post(REGISTER_URL, json=VALID_USER)
    login_r = await client.post(LOGIN_URL, json={"login": "alice", "password": "AlicePass1"})
    tokens = login_r.json()
    access = tokens["access_token"]
    refresh = tokens["refresh_token"]

    r = await client.post(LOGOUT_ALL_URL, headers={"Authorization": f"Bearer {access}"})
    assert r.status_code == 204

    # All refresh tokens should be revoked
    r2 = await client.post(REFRESH_URL, json={"refresh_token": refresh})
    assert r2.status_code in (401, 403)
