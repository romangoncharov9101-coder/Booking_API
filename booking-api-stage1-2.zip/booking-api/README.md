# Booking API

Production-grade FastAPI backend for booking venues, services, and resources.
Barber shops, restaurants, coworking spaces, clinics — any venue with schedulable slots.

## Features

- **JWT auth** with access/refresh token rotation
- **RBAC**: `user` / `venue_owner` / `admin`
- **Venues, Services, Resources** with flexible scheduling
- **Conflict-safe bookings** via PostgreSQL exclusion constraint (`EXCLUDE USING gist`)
- **Waitlist** with email notifications when a slot opens
- **Background tasks** via Celery + Redis
- **Recurring bookings**
- **Reviews & ratings**
- **Audit log**
- **Full-text search** on venues (pg_trgm)
- **ICS calendar export** for bookings
- **Mock payment** integration
- **Rate limiting** on auth endpoints
- Structured JSON logging with structlog
- OpenAPI / Swagger docs

## Stack

| Layer | Technology |
|---|---|
| Framework | FastAPI 0.115+ |
| Database | PostgreSQL 16 |
| ORM | SQLAlchemy 2.x async |
| Migrations | Alembic |
| Validation | Pydantic v2 |
| Auth | JWT (python-jose) + argon2 |
| Queue | Celery + Redis |
| Email | aiosmtplib + Jinja2 templates |
| Testing | pytest-asyncio + httpx |
| Lint | Ruff + mypy |
| Container | Docker + Docker Compose |

## Project Structure

```
app/
├── core/           # Config, security, exceptions, logging
├── db/             # Engine, session, base model
├── models/         # SQLAlchemy ORM models
├── schemas/        # Pydantic request/response schemas
├── repositories/   # DB query layer
├── services/       # Business logic
├── api/
│   ├── deps.py     # FastAPI dependencies (auth, roles)
│   └── v1/routers/ # Route handlers
├── tasks/          # Celery tasks
└── tests/
alembic/            # Migrations
templates/email/    # Jinja2 email templates
```

## Quick Start

### 1. Clone and configure

```bash
git clone <repo>
cd booking-api
cp .env.example .env
```

### 2. Run with Docker Compose

```bash
docker compose up --build
```

Services:
- **API**: http://localhost:8000
- **Swagger**: http://localhost:8000/docs
- **Mailhog**: http://localhost:8025
- **PostgreSQL**: localhost:5432
- **Redis**: localhost:6379

### 3. Run migrations

```bash
docker compose exec api alembic upgrade head
```

### 4. Run tests

```bash
docker compose exec api pytest -v --cov=app --cov-report=term-missing
```

## API Overview

```
POST   /api/v1/auth/register
POST   /api/v1/auth/login
POST   /api/v1/auth/refresh
POST   /api/v1/auth/logout
GET    /api/v1/auth/me

GET    /api/v1/venues
POST   /api/v1/venues
GET    /api/v1/venues/{id}
GET    /api/v1/venues/{id}/availability?service_id=&date=

POST   /api/v1/bookings
GET    /api/v1/bookings/me
POST   /api/v1/bookings/{id}/cancel
GET    /api/v1/bookings/{id}/ics         # Calendar export

POST   /api/v1/waitlist
GET    /api/v1/waitlist/me

GET    /api/v1/venues/{id}/reviews
POST   /api/v1/venues/{id}/reviews
```

## Key Design Decisions

### Concurrency-safe bookings

Overlapping bookings are prevented at the **database level**, not just in Python:

```sql
ALTER TABLE bookings
ADD CONSTRAINT bookings_no_overlap
EXCLUDE USING gist (
    resource_id WITH =,
    tstzrange(starts_at, ends_at) WITH &&
)
WHERE (status IN ('pending', 'confirmed'));
```

Two simultaneous requests for the same slot → PostgreSQL raises an exclusion violation → API returns `409 Conflict`.

### Architecture

- Routers call **Services**, not repositories directly
- Services contain all business logic and call **Repositories**
- Repositories are pure DB query objects, fully testable with dependency injection

### Email notifications

1. An event is written to `notification_events` (status = `pending`)
2. Celery worker picks it up every 60 seconds
3. Sends via SMTP, updates status to `sent` or `failed`
4. Failed events can be retried

## Development Plan

- [x] Stage 1: Base project, models, migrations, Docker
- [ ] Stage 2: Auth (register, login, JWT, refresh token rotation)
- [ ] Stage 3: Venues, Services, Resources, Working hours
- [ ] Stage 4: Availability engine
- [ ] Stage 5: Bookings with concurrency protection
- [ ] Stage 6: Waitlist
- [ ] Stage 7: Email notifications + Celery
- [ ] Stage 8: Tests, Reviews, Advanced features, CI

## What's next to improve

- Google Calendar OAuth integration
- Stripe payment mock → real integration
- WebSocket notifications
- Admin dashboard
- Rate limiting per IP
- Outbox pattern for guaranteed notification delivery
